package demoProject;
import java.util.Scanner;

import org.testng.annotations.Test;

import demoProject.ExistingCustomerLogin;
import demoProject.NewCustomerLogin;
public class Executor {

	@Test
	public void method() throws InterruptedException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Please Enter the customer type before launching the browser in order to apply for loan  : 1. New Customer   2.Existing Customer");
		int k=sc.nextInt();
		switch(k)
		{
		case 1: NewCustomerLogin cl=new NewCustomerLogin();
		        cl.NewCustomer();
			break;
	     case 2: System.out.println("Welcome to MoneyMart:");
	           ExistingCustomerLogin ecl=new ExistingCustomerLogin();
	           System.out.println("Please enter your username");
	           String username=sc.next();
	           System.out.println("Please enter your Password");
	           String password=sc.next();
	           
	          ecl.ExistCustomer1(username, password);
	        break;
	     default:
		System.out.println("Invalid selection");
		}
		
		
	}

}
