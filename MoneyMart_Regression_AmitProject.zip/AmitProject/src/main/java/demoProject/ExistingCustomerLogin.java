package demoProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExistingCustomerLogin {
	WebElement element_myaccount;
	WebElement user_email_add,user_pass,signIn_btn,applyLoan_btn,continue_btn,PersInfo_contBtn,emp_netpay,emp_payfrq,emp_payfrq_drpdwn,firstPay_date,firstpay_year,firstpay_month,firstpay_day,income_continue_btn;
	WebElement transit_num,institution_num,acc_num,cnfrm_acc_num,direct_depo,submit_btn;

	public void ExistCustomer1(String user, String pass) throws InterruptedException 
	{

		System.setProperty("webdriver.chrome.driver","C:\\Users\\k.amit\\eclipse-workspace\\AmitProject\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseUrl = "https://preview1.moneymart.ca/";
		driver.get(baseUrl);
		driver.manage().window().maximize();

		element_myaccount=driver.findElement(By.linkText("My Account"));
		element_myaccount.click();
		Thread.sleep(2000);
		user_email_add=driver.findElement(By.xpath("//*[@id=\"userEmailHeader1\"]"));
		user_email_add.sendKeys(user);
		user_pass=driver.findElement(By.xpath("//*[@id=\"passwordIDHeader1\"]"));
		user_pass.sendKeys(pass);

		signIn_btn=driver.findElement(By.id("btnlogin"));
		signIn_btn.click();
		Thread.sleep(1000);
		applyLoan_btn=driver.findElement(By.xpath("/html/body/div[10]/div[12]/div[2]/div[1]/div[1]/a"));
		applyLoan_btn.click();
		continue_btn=driver.findElement(By.id("skClick"));
		continue_btn.click();
		Thread.sleep(1500);
		PersInfo_contBtn=driver.findElement(By.xpath("//*[@id=\"accordion-1\"]/div[8]/a"));
		PersInfo_contBtn.click();
		Thread.sleep(4000);
		emp_netpay=driver.findElement(By.xpath("//*[@id=\"netPay\"]"));
		emp_netpay.clear();
		emp_netpay.sendKeys("4500");
		Thread.sleep(1000);
		emp_payfrq=driver.findElement(By.xpath("//*[@id=\"divfrequencyPay\"]/div"));
		emp_payfrq.click();
		emp_payfrq_drpdwn=driver.findElement(By.xpath("//*[@id=\"divfrequencyPay\"]/div/div/ul/li[2]/a"));
		emp_payfrq_drpdwn.click();
		firstPay_date=driver.findElement(By.xpath("//*[@id=\"nextPayDate\"]"));
		firstPay_date.click();
		firstpay_year=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/select[2]"));
		firstpay_year.click();
		firstpay_month=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/select[1]"));
		firstpay_month.click();
		Thread.sleep(1000);
		firstpay_day=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[5]/td[5]/a"));
		firstpay_day.click();
		Thread.sleep(1000);
		income_continue_btn=driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/div[2]/a"));
		income_continue_btn.click();



		transit_num=driver.findElement(By.xpath("//*[@id=\"Transit\"]"));
		transit_num.sendKeys("00091");

		institution_num=driver.findElement(By.xpath("//*[@id=\"FinInstNum\"]"));
		institution_num.sendKeys("010");

		acc_num=driver.findElement(By.xpath("//*[@id=\"BankInfo_BankAccountNumber\"]"));
		acc_num.clear();
		acc_num.sendKeys("9446227815");
		cnfrm_acc_num=driver.findElement(By.xpath("//*[@id=\"BankInfo_ConfirmAccountNumber\"]"));
		cnfrm_acc_num.clear();
		cnfrm_acc_num.sendKeys("9446227815");
		Thread.sleep(3000);

		direct_depo=driver.findElement(By.xpath("//*[@id=\"accordion-3\"]/div[5]/label"));
		direct_depo.click(); 
		direct_depo=driver.findElement(By.xpath("//*[@id=\"accordion-3\"]/div[5]/label"));
		direct_depo.click(); 
		//       clickOption("//*[@id=\"accordion-3\"]/div[5]/label", driver);


		Thread.sleep(5000);

		submit_btn=driver.findElement(By.id("btnSubmit"));
		submit_btn.click();//

		Thread.sleep(5000);
		System.out.println("End of test");
		driver.close();
	}
}
