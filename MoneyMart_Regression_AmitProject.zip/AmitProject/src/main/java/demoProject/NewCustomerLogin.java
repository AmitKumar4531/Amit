package demoProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class NewCustomerLogin {

	WebElement element_myaccount;
	WebElement reg_email,reg_pass,reg_submit,newCustReg,drpdwn;
	WebElement first_name,last_name,email,confirm_email,dob,date_year,date_month,date_day,address,city,zip,home_phn,cell_phn,gender,continue_btn;
	WebElement income,income_drpdwn,emp_name,emp_add,emp_zip,emp_city,emp_phn,emp_netpay,income_option,province_drpdwn,province_option,emp_payfrq,emp_payfrq_drpdwn,firstPay_date,firstpay_year,firstpay_month,firstpay_day,income_continue_btn;
	WebElement transit_num,institution_num,acc_num,cnfrm_acc_num,direct_deposit,aggrement,close_agg,submit_btn;
	public void NewCustomer() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\k.amit\\eclipse-workspace\\AmitProject\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		String baseUrl = "https://preview1.moneymart.ca/";
		driver.get(baseUrl);
		driver.manage().window().maximize();
		element_myaccount=driver.findElement(By.linkText("My Account"));
		element_myaccount.click();
		Thread.sleep(2000);
		newCustReg=driver.findElement(By.xpath("//*[@id=\"login_popup\"]/div[2]/div[2]/div[2]/a"));
		newCustReg.click();
		/*Code for filling the details before applying for loan.*/
		drpdwn=driver.findElement(By.className("sbSelector"));
		drpdwn.click();
		driver.findElement(By.linkText("Ontario")).click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//*[@id=\"onClick\"]")).click();
		first_name=driver.findElement(By.xpath("//*[@id=\"FirstName\"]"));
		first_name.sendKeys("Ram");
		Thread.sleep(1500);
		last_name=driver.findElement(By.xpath("//*[@id=\"LastName\"]"));
		last_name.sendKeys("Baba");
		Thread.sleep(1000);
		email=driver.findElement(By.xpath("//*[@id=\"Email\"]"));
		email.sendKeys("ram.baba@gmail.com");
		Thread.sleep(1000);
		confirm_email=driver.findElement(By.xpath("//*[@id=\"Contact_ConfirmEmail\"]"));
		confirm_email.sendKeys("ram.baba@gmail.com");
		Thread.sleep(1500);
		/*date selection from Date time picker*/
		dob=driver.findElement(By.xpath("//*[@id=\"DOB\"]"));
		dob.click();
		date_year=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/select[2]"));
		Select date_year_drpdwn=new Select(date_year);
		date_year_drpdwn.selectByVisibleText("1990");
		Thread.sleep(1000);
		date_month=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/select[1]"));
		Select date_month_drpdwn=new Select(date_month);
		date_month_drpdwn.selectByVisibleText("Jun");
		Thread.sleep(1000);
		date_day=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[4]/td[4]/a"));
		date_day.click();
		address=driver.findElement(By.xpath("//*[@id=\"Contact_Addresses_0__StreetAddress\"]"));
		address.sendKeys("Daisy Nest Apartment");
		city=driver.findElement(By.xpath("//*[@id=\"Contact_Addresses_0__City\"]"));
		city.sendKeys("Bangalore");
		Thread.sleep(1000);
		zip=driver.findElement(By.xpath("//*[@id=\"zip\"] "));
		zip.sendKeys("A0L7J0A1");
		Thread.sleep(1000);
		home_phn=driver.findElement(By.xpath("//*[@id=\"Contact_HomePhone\"]"));
		home_phn.sendKeys("1256884345");
		cell_phn=driver.findElement(By.xpath("//*[@id=\"Contact_CellPhone\"]"));
		cell_phn.sendKeys("5689324524");
		Thread.sleep(1000);
		gender=driver.findElement(By.xpath("//*[@id=\"accordion-1\"]/div[8]/div/label[2]"));
		gender.click();
		continue_btn=driver.findElement(By.xpath("//*[@id=\"accordion-1\"]/div[9]/a"));
		continue_btn.click();
		/*code for primary income selection*/
		Thread.sleep(4000);
		income_drpdwn=driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/div[1]/div[1]/div[1]/div/div[1]"));
		income_drpdwn.click();
		Thread.sleep(1000);
		income_option=driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/div[1]/div[1]/div[1]/div/div[1]/ul/li[2]/a"));
		income_option.click();
		//province selection
		province_drpdwn=driver.findElement(By.xpath("//*[@id=\"divProvince\"]/div/div[1]/a"));
		province_drpdwn.click();
		Thread.sleep(1000);
		province_option=driver.findElement(By.xpath("//*[@id=\"divProvince\"]/div/div[1]/ul/li[5] "));
		province_option.click();

		emp_name=driver.findElement(By.xpath("//*[@id=\"IncomeDetails_EmployerName\"]"));
		emp_name.sendKeys("sap labs");

		emp_add=driver.findElement(By.xpath("//*[@id=\"IncomeDetails_Address\"]"));
		emp_add.sendKeys("daisy nest partment");

		emp_zip=driver.findElement(By.xpath("//*[@id=\"IncomeDetails_PostalCode\"]"));
		emp_zip.sendKeys("A0L7J0A1A0");

		emp_city=driver.findElement(By.xpath("//*[@id=\"IncomeDetails_City\"]"));
		emp_city.sendKeys("Bangalore");
		Thread.sleep(1000);
		emp_phn=driver.findElement(By.id("IncomeDetails_WorkPhone"));
		emp_phn.sendKeys("5689741324");

		emp_netpay=driver.findElement(By.xpath("//*[@id=\"netPay\"]"));
		emp_netpay.sendKeys("3500");
		Thread.sleep(1000);
		emp_payfrq=driver.findElement(By.xpath("//*[@id=\"divfrequencyPay\"]/div"));
		emp_payfrq.click();
		emp_payfrq_drpdwn=driver.findElement(By.xpath("//*[@id=\"divfrequencyPay\"]/div/div/ul/li[2]/a"));
		emp_payfrq_drpdwn.click();
		firstPay_date=driver.findElement(By.xpath("//*[@id=\"nextPayDate\"]"));
		firstPay_date.click();
		firstpay_year=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/select[2]"));
		firstpay_year.click();
		firstpay_month=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/select[1]"));
		firstpay_month.click();
		Thread.sleep(1000);
		firstpay_day=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[5]/td[5]/a"));
		firstpay_day.click();
		Thread.sleep(1000);
		income_continue_btn=driver.findElement(By.xpath("//*[@id=\"accordion-2\"]/div[2]/a"));
		income_continue_btn.click();

		//Code for filling account details
		transit_num=driver.findElement(By.xpath("//*[@id=\"Transit\"]"));
		transit_num.sendKeys("00091");

		institution_num=driver.findElement(By.xpath("//*[@id=\"FinInstNum\"]"));
		institution_num.sendKeys("010");

		acc_num=driver.findElement(By.xpath("//*[@id=\"BankInfo_BankAccountNumber\"]"));
		acc_num.sendKeys("983504578");

		cnfrm_acc_num=driver.findElement(By.xpath("//*[@id=\"BankInfo_ConfirmAccountNumber\"]"));
		cnfrm_acc_num.sendKeys("983504578");

		direct_deposit=driver.findElement(By.xpath("//*[@id=\"accordion-3\"]/div[5]/label"));
		direct_deposit.click();

		submit_btn=driver.findElement(By.id("btnSubmit"));
		submit_btn.click();
	}


}
